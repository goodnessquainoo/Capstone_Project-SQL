-- creating database --
CREATE DATABASE Famous_Ghanaian_Entertainers;
USE Famous_Ghanaian_Entertainers;

--  creating People Table --
CREATE TABLE People (
    Person_id INT AUTO_INCREMENT PRIMARY KEY,
    Celebrity_name TEXT NOT NULL,
    Date_of_birth DATE,
    Nationality TEXT,
    Region TEXT,
    Occupation TEXT
);
-- Inserting Values --
INSERT INTO People (Celebrity_name, Date_of_birth, Nationality, Region, Occupation) VALUES
('John Dumelo', '1984-02-03', 'Ghanaian', 'Greater Accra', 'Actor'),
('Shatta Wale', '1984-10-17', 'Ghanaian', 'Greater Accra', 'Singer'),
('Joselyn Dumas', '1980-08-31', 'Ghanaian', 'Greater Accra', 'Actor'),
('Stonebwoy', '1988-03-05', 'Ghanaian', 'Volta Region', 'Singer'),
('Yvonne Nelson', '1985-11-12', 'Ghanaian', 'Greater Accra', 'Actor'),
('Kuami Eugene', '1997-04-15', 'Ghanaian', 'Eastern Region', 'Singer'),
('Nana Ama McBrown', '1977-08-15', 'Ghanaian', 'Ashanti Region', 'Actor'),
('Sarkodie', '1988-07-10', 'Ghanaian', 'Ashanti Region', 'Singer'),
('Van Vicker', '1977-08-01', 'Ghanaian', 'Greater Accra', 'Actor'),
('Fuse ODG', '1988-12-02', 'Ghanaian', 'Greater Accra', 'Singer'),
('Majid Michel', '1980-09-22', 'Ghanaian', 'Greater Accra', 'Actor'),
('Becca', '1984-08-15', 'Ghanaian', 'Greater Accra', 'Singer'),
('Lydia Forson', '1984-10-24', 'Ghanaian', 'Central Region', 'Actor'),
('Samini', '1981-12-22', 'Ghanaian', 'Ashanti Region', 'Singer'),
('Jackie Appiah', '1983-12-05', 'Ghanaian', 'Greater Accra', 'Actor'),
('MzVee', '1992-06-23', 'Ghanaian', 'Greater Accra', 'Singer'),
('Adjetey Anang', '1978-07-03', 'Ghanaian', 'Greater Accra', 'Actor'),
('Efya', '1987-04-10', 'Ghanaian', 'Greater Accra', 'Singer'),
('Nadia Buari', '1982-11-21', 'Ghanaian', 'Greater Accra', 'Actor'),
('King Promise', '1996-06-06', 'Ghanaian', 'Greater Accra', 'Singer');

-- Creating the Movies Table --
CREATE TABLE Movies (
    Movie_id INT AUTO_INCREMENT PRIMARY KEY,
    Title TEXT NOT NULL,
    Release_year INT,
    Genre TEXT,
    Box_office_revenue DECIMAL(15, 2),
    Person_id INT,
    FOREIGN KEY (Person_id) REFERENCES People(Person_id)
);
-- Inserting Values --
INSERT INTO Movies (Title, Release_year, Genre, Box_office_revenue, Person_id) VALUES
('A Northern Affair', 2013, 'Drama', 500000, 1),
('4Play Reloaded', 2011, 'Comedy', 300000, 3),
('The Perfect Picture', 2009, 'Romance', 450000, 5),
('Single and Married', 2012, 'Comedy', 400000, 7),
('Adams Apple', 2011, 'Drama', 350000, 9),
('Somewhere in Africa', 2012, 'Drama', 600000, 11),
('The Perfect Picture', 2009, 'Romance', 450000, 15),
('4Play Reloaded', 2011, 'Comedy', 300000, 13),
('The Game', 2017, 'Thriller', 500000, 17),
('Potomanto', 2013, 'Drama', 550000, 19);

-- Creating Music Table --
CREATE TABLE Music (
    Music_id INT AUTO_INCREMENT PRIMARY KEY,
    Title TEXT NOT NULL,
    Release_year INT,
    Genre TEXT,
    Album_name TEXT,
    Streams INT,
    Person_id INT,
    FOREIGN KEY (Person_id) REFERENCES People(Person_id)
);
-- Inserting Values --
INSERT INTO Music (Title, Release_year, Genre, Album_name, Streams, Person_id) VALUES
('Taking Over', 2017, 'Dancehall', 'Reign', 10000000, 2),
('Baafira', 2019, 'Afrobeats', 'Anloga Junction', 8000000, 4),
('Angela', 2020, 'Afrobeats', 'Son of Africa', 12000000, 6),
('Adonai', 2015, 'Hip Hop', 'Mary', 15000000, 8),
('Antenna', 2014, 'Afrobeats', 'T.I.N.A', 9000000, 10),
('Daa Ke Daa', 2013, 'Afrobeats', 'Time for Me', 5000000, 12),
('I Love You', 2017, 'Afrobeats', 'Unveiling', 7000000, 14),
('My Own', 2016, 'Reggae', 'Dancehall King', 8000000, 16),
('CCTV', 2019, 'Afrobeats', 'King of Boys', 9000000, 20),
('Best in Me', 2019, 'Afrobeats', 'Efya', 9500000, 18);

-- Creating Awards Table --
CREATE TABLE Awards (
    Award_id INT AUTO_INCREMENT PRIMARY KEY,
    Award_name TEXT NOT NULL,
    Category TEXT,
    Award_year INT,
    Person_id INT,
    FOREIGN KEY (Person_id) REFERENCES People(Person_id)
);
-- Inserting Values --
INSERT INTO Awards (Award_name, Category, Award_year, Person_id) VALUES
('Ghana Movie Awards', 'Best Actor', 2014, 1),
('Vodafone Ghana Music Awards', 'Artiste of the Year', 2015, 2),
('Africa Magic Viewers Choice Awards', 'Best Actress', 2016, 3),
('Ghana Music Awards', 'Best Reggae/Dancehall Artiste', 2018, 4),
('3Music Awards', 'Best Male Act', 2021, 6),
('Ghana Movie Awards', 'Best Actor', 2013, 11),
('Vodafone Ghana Music Awards', 'Best Female Vocalist', 2014, 12),
('Africa Magic Viewers Choice Awards', 'Best Actress in a Comedy', 2015, 13),
('3Music Awards', 'Best Female Act', 2018, 16),
('Africa Movie Academy Awards', 'Best Actor in a Leading Role', 2019, 17);


-- Creating Contributions Table --
CREATE TABLE Contributions (
    Contribution_id INT AUTO_INCREMENT PRIMARY KEY,
    Person_id INT,
    Movie_industry_role TEXT,
    Music_industry_role TEXT,
    FOREIGN KEY (Person_id) REFERENCES People(Person_id)
);
-- Inserting Vales --
INSERT INTO Contributions (Person_id, Movie_industry_role, Music_industry_role) VALUES
(1,"lead Actor", ""),
(2, "", "Singer"),
(3, "Lead Actress", ""),
(4,"", "Singer"),
(5, "Lead Actress", "Singer"),
(6, "", "Singer"),
(7, "Lead Actress", "Singer"),
(8, "", "Singer"),
(9, "Lead Actor", ""),
(10, "", "Singer"),
(11,"Lead Actor", "Singer"),
(12, "Lead Actress", "Singer"),
(13, "Lead Actress", ""),
(14, "", "Singer"),
(15, "Lead Actress", ""),
(16, "", "Singer"),
(17, "Lead Actor", ""),
(18, "", "Singer"),
(19, "Lead Actress", ""),
(20, "", "Singer");

-- Creating Possession Table --
CREATE TABLE Possessions (
    Possession_id INT AUTO_INCREMENT PRIMARY KEY,
    Person_id INT,
    Possession_type TEXT,
    Networth DECIMAL(15, 2),
    Purchase_year INT,
    FOREIGN KEY (Person_id) REFERENCES People(Person_id)
);

INSERT INTO Possessions (Person_id, Possession_type, Networth, Purchase_year) VALUES
(1, "House", 900000.00, 2024),
(2, "Jewelry", 1000000.00, 2018),
(3, "Car", 90000.00, 2019),
(4, "Car", 100000.00, 2020),
(5, "House", 600000.00, 2018),
(6, "Car", 50000.00, 2021),
(7, "Real Estate", 1000000.00, 2019),
(8, "Island", 2000000.00, 2021),
(9, "House", 750000.00, 2018),
(10, "Boat", 120000.00, 2021),
(11, "House", 700000.00, 2018),
(12, "Jewelry", 30000.00, 2019),
(13, "Car", 110000.00, 2018),
(14, "Jewelry", 20000.00, 2020),
(15, "House", 1000000.00, 2018),
(16, "Car", 95000.00, 2021),
(17, "House", 700000.00, 2019),
(18, "Jewelry", 25000.00, 2019),
(19, "House", 850000.00, 2020),
(20, "Car", 130000.00, 2022);

-- Querries --
-- 1. Finding celebrities who have won an award and have starred in a movie with a box office revenue greater than 400,000 --
-- 2. List the celebrities who have released music in the 'Afrobeats' genre and have a net worth greater than 50,000 --
-- 3. Retrieve the names of celebrities who have won an award in 2018 or later and have a music album released after 2017 --
-- 4. Find celebrities who have acted in movies of the 'Drama' genre and have also released music in the 'Afrobeats' genre --
-- 5. List the celebrities who have an Island as a possession and have released a song with more than 9,000,000 streams --
-- 6. List the celebrities who have a possession purchased in 2018 or laterband have released a song in the same period--
-- 7.Calculate and compare the average networth of Celebrities in the music and movie industries. --


SELECT * FROM People;
SELECT * FROM Movies;
SELECT * FROM Music;
SELECT * FROM Possessions;
SELECT * FROM Awards;
SELECT * FROM Contributions;


-- 1. Finding celebrities who have won an award and have starred in a movie with a box office revenue greater than 400,000 --
SELECT People.Celebrity_name, Awards.Category, Movies.Box_office_revenue
FROM People
JOIN Awards
ON People.Person_id = Awards.Person_id
JOIN Movies
ON People.Person_id = Movies.Person_id
HAVING Movies.Box_office_revenue > 400000;

-- 2. Listing the celebrities who have released music in the 'Afrobeats' genre and have a net worth greater than 50000 --
SELECT People.Celebrity_name, Music.Genre, Possessions.Networth 
FROM People
JOIN Music
ON People.Person_id = Music.Person_id
JOIN Possessions
ON People.Person_id = Possessions.Person_id
WHERE Music.Genre = 'Afrobeats'
AND Possessions.Networth > 50000;

-- 3. Retrieving the names of celebrities who have won an award in 2018 or later and have a music album released after 2017 --
SELECT People.Celebrity_name, Awards.Category, Awards.Award_year, Music.Album_name
FROM People
JOIN Awards
ON People.Person_id = Awards.Person_id
JOIN Music
ON People.Person_id = Music.Person_id
WHERE Awards.Award_year >= 2018
AND Music.Release_year > 2017;

 -- 4. Finding celebrities who have acted in movies of the 'Drama' genre and have also released music in the 'Afrobeats' genre --
SELECT People.Celebrity_Name, Movies.Genre, Music.Album_name
FROM People
JOIN Movies
ON People.Person_id = Movies.Person_id
JOIN Music
ON People.Person_id = Music.Person_id
WHERE Movies.Genre = 'Drama'
AND Music.Genre = 'Afrobeats';

 -- 5. Listing celebrities who have an Island as a possession and have released a song with more than 7,000,000 streams --
 SELECT People.Celebrity_name, Possessions.Possession_type, Music.Streams
 FROM People
 JOIN Possessions
 ON People.Person_id = Possessions.Person_id
 JOIN Music
 ON People.Person_id = Music.Person_id
 WHERE Possessions.Possession_type ='Island'
 AND Music.Streams > 7000000;
 
  -- 6. Listing celebrities who have a possession purchased in 2018 or later and have released a song in the same period --
  SELECT People.Celebrity_name, Possessions.Purchase_year, Music.Release_year
  FROM People
  JOIN Possessions
  ON People.Person_id = Possessions.Person_id
  JOIN Music
  ON People.Person_id = Music.Person_id
  WHERE Possessions.Purchase_year>=2018
  AND Music.Release_year >= 2018
  ORDER BY Possessions.Purchase_year DESC;
  
  -- 7.Calculating and comparing the average networth of celebrities in the music and movie industries. --
-- Music Industry --
SELECT Music.Genre, AVG(Networth) AS Avg_Networth
FROM Possessions
JOIN Music
ON Possessions.Person_id = Music.Person_id
GROUP BY Music.Genre
ORDER BY Avg_Networth DESC;

-- Movie Industry --
SELECT Movies.Genre, AVG(Networth) AS Avg_Networth
FROM Possessions
JOIN Movies
ON Possessions.Person_id = Movies.Person_id
GROUP BY Movies.Genre
ORDER BY Avg_Networth DESC;

-- Run both codes simultaneously to compare --

